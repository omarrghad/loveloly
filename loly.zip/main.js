// تأثيرات النافبار عند التمرير
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// تأثيرات الظهور عند التمرير
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = 1;
            entry.target.style.transform = 'translateY(0)';
        }
    });
});

document.querySelectorAll('.grade-card').forEach((el) => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(50px)';
    observer.observe(el);
});

// تأثيرات الخلفية الديناميكية
const hero = document.querySelector('.hero');
document.addEventListener('mousemove', (e) => {
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    hero.style.backgroundPosition = `${x * 50}% ${y * 50}%`;
});

// إضافة جسيمات متحركة في الخلفية
particlesJS('hero', {
    particles: {
        number: { value: 80 },
        color: { value: '#6C5CE7' },
        opacity: { value: 0.5 },
        size: { value: 3 },
        move: { 
            enable: true,
            speed: 1,
            direction: "none",
            random: false,
            straight: false,
            out_mode: "out",
            bounce: false,
        }
    },
    interactivity: {
        detect_on: "canvas",
        events: {
            onhover: { enable: true, mode: "repulse" },
            onclick: { enable: true, mode: "push" },
            resize: true
        }
    }
});
